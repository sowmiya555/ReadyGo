package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.CabBooking;
@Service
public class CabBookingService {
	@Autowired
	 ReadyGoDAO dao;
	
	

	 public ArrayList<CabBooking> displayBookings()
		{
			return dao.displayBookings();
		}
     public String postBooking(CabBooking cab)
     {
    	 return dao.postBooking(cab);
     }
}
