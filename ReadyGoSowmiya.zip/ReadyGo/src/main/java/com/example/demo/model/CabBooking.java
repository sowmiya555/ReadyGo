package com.example.demo.model;

public class CabBooking {

	public String getPickUpPoint() {
		return pickUpPoint;
	}

	public void setPickUpPoint(String pickUpPoint) {
		this.pickUpPoint = pickUpPoint;
	}


	private int bookingId;
	private int cabId;
	private String source;
	private String destination;
	private String journeyDate;
	private String journeyTime;
	private int amount;
	private String pickUpPoint;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getCabId() {
		return cabId;
	}

	public void setCabId(int cabId) {
		this.cabId = cabId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}

	public String getJourneyTime() {
		return journeyTime;
	}

	public void setJourneyTime(String journeyTime) {
		this.journeyTime = journeyTime;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}


	@Override
	public String toString() {
		return "CabBooking [bookingId=" + bookingId + ", cabId=" + cabId + ", source=" + source + ", destination="
				+ destination + ", journeyDate=" + journeyDate + ", journeyTime=" + journeyTime + ", amount=" + amount
				+ ", pickUpPoint=" + pickUpPoint + "]";
	}

}
