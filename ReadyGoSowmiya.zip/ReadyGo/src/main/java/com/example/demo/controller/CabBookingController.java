package com.example.demo.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.model.CabBooking;
import com.example.demo.services.CabBookingService;


@Controller
@ResponseBody
public class CabBookingController {

	@Autowired
	CabBookingService service;
	
	
	@GetMapping("/displaybooking")
	 public ArrayList<CabBooking> displayBookings()
	 {
		 return service.displayBookings();
	 }
	@RequestMapping("/bookingForm")
	public ModelAndView displayBookingForm()
	{
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("cabBookingForm");
		return modelAndView;
	}
	@PostMapping("/submit")
	public ModelAndView method(CabBooking cab)
	{
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("cabBookingForm");
		return modelAndView.addObject("submit",service.postBooking(cab));
	}
	
	
}
