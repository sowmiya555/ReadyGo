package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.CabBooking;
import com.example.demo.model.User;
@Repository
public class ReadyGoDAO {
	
			@SuppressWarnings("null")
			public static Connection connectToDB()
			{
				Connection connection=null;
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
					return connection;
				} 
				catch (ClassNotFoundException | SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
					
						try {
							connection.close();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						return null;
				}

		}
			
			public ArrayList<CabBooking> displayBookings()
			{
				ArrayList<CabBooking> list = new ArrayList<CabBooking>();
				try
				{
					Connection con = connectToDB();
					PreparedStatement stmt = con.prepareStatement("select * from cabBooking");
					ResultSet rs = stmt.executeQuery();
					while(rs.next())
					{
						CabBooking cabs = new CabBooking();
						cabs.setBookingId(rs.getInt(1));
						cabs.setCabId(rs.getInt(2));
						cabs.setSource(rs.getString(3));
						cabs.setDestination(rs.getString(4));
						cabs.setJourneyDate(rs.getString(5));
						cabs.setJourneyTime(rs.getString(6));
						cabs.setAmount(rs.getInt(7));
						cabs.setPickUpPoint(rs.getString(8));
						list.add(cabs);
					}
					con.close();
				}
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return list;
			}
			public static int getCounter() {
				// TODO Auto-generated method stub
				Connection conn = connectToDB();
				int count = 1;
				try {
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery("select max(bookingId) from cabBooking");
					while(rs.next()) {
						count=rs.getInt(1);
						count++;
					}
		  // throw error: Invalid column index
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return count;
			}
			public String postBooking(CabBooking cab)
			{
				try {
			
				    int amt=2000;
					Connection con = connectToDB();
					PreparedStatement stmt = con.prepareStatement("insert into cabBooking values(?,?,?,?,?,?,?,?)");
					stmt.setInt(1,getCounter());
					stmt.setInt(2,cab.getCabId());
					stmt.setString(3,cab.getSource());
					stmt.setString(4,cab.getDestination());
					stmt.setString(5,cab.getJourneyDate());
					stmt.setString(6,cab.getJourneyTime());
					stmt.setInt(7,amt);
					stmt.setString(8,cab.getPickUpPoint());
					
					int affectedRows = stmt.executeUpdate();
					System.out.println("Affected rows:"+affectedRows);
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return "Booking Successful";
			}
		
}
