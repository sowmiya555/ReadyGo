package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.CabBooking;
import com.example.demo.services.CabService;

public class CabController {

	@Autowired
	CabService service;
	@RequestMapping("/addBooking")
	public void addBooking(@RequestParam("bookingId") int bookingId,@RequestParam("cabId") int cabId, @RequestParam("source") String source, @RequestParam("destination") String destination, @RequestParam("journeyDate") String journeyDate, @RequestParam("journeyTime") String journeyTime, @RequestParam("amount") double amount, @RequestParam("noOfPassengers") int noOfPassengers )
	{
		CabBooking cab = new CabBooking();
		cab.setBookingId(bookingId);
		cab.setCabId(cabId);
		cab.setSource(source);
		cab.setDestination(destination);
		cab.setJourneyDate(journeyDate);
		cab.setJourneyTime(journeyTime);
		cab.setAmount(amount);
		cab.setNoOfPassengers(noOfPassengers);
        service.addBooking(cab);
        System.out.println(cab);
	}
}
