package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.CabBooking;

public class CabService {
	@Autowired
	ReadyGoDAO dao;
	 public void addBooking(CabBooking cab)
	 {
		 dao.addBooking(cab);
	 }

}
