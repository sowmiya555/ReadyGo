package com.example.demo.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.demo.model.CabBooking;

public class ReadyGoDAO {
	
			@SuppressWarnings("null")
			public static Connection connectToDB()
			{
				Connection connection=null;
				try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				  connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","admin");
					return connection;
				} 
				catch (ClassNotFoundException | SQLException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
					
						try {
							connection.close();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						return null;
				}

		}
			public void addBooking(CabBooking cab)
			{
				try {
			
				    
					Connection con = connectToDB();
					PreparedStatement stmt = con.prepareStatement("insert into cabBooking values(?,?,?,?,?,?,?,?)");
					stmt.setInt(1,cab.getBookingId());
					stmt.setInt(2,cab.getCabId());
					stmt.setString(3,cab.getSource());
					stmt.setString(4,cab.getDestination());
					stmt.setString(5,cab.getJourneyDate());
					stmt.setString(6,cab.getJourneyTime());
					stmt.setDouble(7,cab.getAmount());
					stmt.setInt(8, cab.getNoOfPassengers());
					
					int affectedRows = stmt.executeUpdate() ;
					System.out.println("Affected rows:"+affectedRows);
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
}
